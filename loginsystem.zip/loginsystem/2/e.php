<?php
$r1=rand(1,5);
$r2=rand(6,10);
$r3=rand(11,15);
$r4=rand(16,20);
//$filename = "newfile.txt";
   $file = fopen( "newfile1.txt", "w" );
   fwrite( $file, $r1);
   fclose( $file );
   $file = fopen( "newfile2.txt", "w" );
   fwrite( $file, $r2);
   fclose( $file );
   $file = fopen( "newfile3.txt", "w" );
   fwrite( $file, $r3);
   fclose( $file );
   $file = fopen( "newfile4.txt", "w" );
   fwrite( $file, $r4);
   fclose( $file );
