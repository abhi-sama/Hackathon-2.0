
<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h2 align="center">Download Question Papers</h2><br><br><br>
<form class="signup-form" action="1\pdfgenerator1.php" method="POST">
<button  type="submit"> Download Sibject1</button><br>
</form>
<form class="signup-form" action="2\pdfgenerator2.php" method="POST">
<button  type="submit">Download Subject2</button><br>
</form>
<form class="signup-form" action="3\pdfgenerator3.php" method="POST">
<button  type="submit">Download Subject3</button><br>
</form>`
</body>
</html>

