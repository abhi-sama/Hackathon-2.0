<?php
			if (isset($_SESSION['u_id'])) {
				$A = "Loggedin";
				echo $A;
				include_once'alpha.php';
			}
			else{
			$B="Not";
			echo $B;
			}
		?>