<?php
	include_once 'header1.php';
?>

<section class="main-container">
	<div class="main-wrapper">
		<h2>Add College</h2>
		<form class="signup-form" action="includes/signup.inc.php" method="POST">
			<input type="text" name="first" placeholder="Enter College Name">
			<input type="text" name="last" placeholder="City">
			<input type="text" name="email" placeholder="College E-mail">
			<input type="text" name="uid" placeholder="Username">
			<input type="password" name="pwd" placeholder="Password">
			<button type="submit" name="submit">DONE!</button><br><br>
<br><br><br>		</form>
<a href="question.php">Set Paper</a>

	</div>
</section>

<?php
	include_once 'footer.php';
?>