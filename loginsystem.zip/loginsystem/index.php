<html>
<?php
	include_once 'header.php';
?>

<section class="main-container">
	<div class="main-wrapper">
		<h2>Institute Login</h2>
	<?php
			
		include_once 'handler.php';
		?>
		

	</div>
</section>
	
<?php
	include_once 'footer.php';
?>
</html>
