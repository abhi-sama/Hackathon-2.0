<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h2 align="center">Set Question Papers</h2><br><br><br>
<form class="signup-form" action="1\e.php" method="POST">
<button  type="submit">Sibject1</button><br>
</form>
<form class="signup-form" action="2\e.php" method="POST">
<button  type="submit">Subject2</button><br>
</form>
<form class="signup-form" action="3\e.php" method="POST">
<button  type="submit">Subject3</button><br>
</form>`
</body>
</html>
