<?php
$filename1="newfile1.txt";
$file=fopen($filename1,"r+");
$filesize=filesize($filename1);
$q1=fread($file,$filesize);
fclose($file);

$filename2="newfile2.txt";
$file=fopen($filename2,"r+");
$filesize=filesize($filename2);
$q2=fread($file,$filesize);
fclose($file);


$filename3="newfile3.txt";
$file=fopen($filename3,"r+");
$filesize=filesize($filename3);
$q3=fread($file,$filesize);
fclose($file);


$filename4="newfile4.txt";
$file=fopen($filename4,"r+");
$filesize=filesize($filename4);
$q4=fread($file,$filesize);
fclose($file);


$Q1=" Question 41";
$Q2="Question42 ";
$Q3="Question43 ";
$Q4=" Question44";
$Q5=" Question45";
$Q6=" Question46";
$Q7=" Question47";
$Q8=" Question48";
$Q9=" Question49";
$Q10="Question50 ";
$Q11="Question51 ";
$Q12=" Question52";
$Q13=" Question53";
$Q14=" Question54";
$Q15="Question55 ";
$Q16="Question56";
$Q17=" Question57";
$Q18=" Question58";
$Q19="Question59 ";
$Q20=" Question60";

switch($q1)
  {
  case 1:
  $QS1=$Q1;
  break;
  case 2:
  $QS1=$Q2;
  break;
  case 3:
  $QS1=$Q3;
  break;
  case 4:
  $QS1=$Q4;
  break;
  case 5:
  $QS1=$Q5;
  break;
  }
  switch($q2)
  {case 6:
  $QS2=$Q6;
  break;
  case 7:
  $QS2=$Q7;
  break;
  case 8:
  $QS2=$Q8;
  break;
  case 9:
  $QS2=$Q9;
  break;
  case 10:
  $QS2=$Q10;
  break;
  }
  switch($q3)

  {case 11:
  $QS3=$Q11;
  break;
  case 12:
  $QS3=$Q12;
  break;
  case 13:
  $QS3=$Q13;
  break;
  case 14:
  $QS3=$Q14;
  break;
  case 15:
  $QS3=$Q15;
  break;
  
  }
  switch($q4)
  {case 16:
  $QS4=$Q16;
  break;
  case 17:
  $QS4=$Q17;
  break;
  case 18:
  $QS4=$Q18;
  break;
  case 19:
  $QS4=$Q19;
  break;
  case 20:
  $QS4=$Q20;
  break;
  }
  require('../fpdf/fpdf.php');function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}
  class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('qr.png',10,6,30);
    // Arial bold 15
    $this->Ln();
    $this->SetFont('Arial','B',30);
    // Move to the right
    $this->Cell(40);
    // Title
    $this->Cell(145,12,'SAMPLE QUESTION PAPER',1,0,'C');
    // Line break
    $this->Ln(20);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',13);
    // Page number
    $this->Ln(5);
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
	$this->Cell(0,10,'IP'.get_client_ip(),0,0,'C');
}
}

// Instanciation of inherited class

$pdf = new PDF();
$ip=get_client_ip();

$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',20);
$pdf->Ln(10);
$pdf->Cell(0,10,$QS1,0,1);
$pdf->Ln(5);
$pdf->Cell(0,10,$QS2,0,1);
$pdf->Ln(5);
$pdf->Cell(0,10,$QS3,0,1);
$pdf->Ln(5);
$pdf->Cell(0,10,$QS4,0,1);
$pdf->Ln(15);


$pdf->Output();